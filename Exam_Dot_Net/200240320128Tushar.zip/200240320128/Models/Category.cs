﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DotNetExam.Models
{
    public class Category
    {
        public int CatergoryId { get; set; }
        public string CatergoryName { get; set; }

    }
}